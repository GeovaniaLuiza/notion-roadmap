# Defesa de Trabalho de Conclusão – NIT23

Datas: 15/01/2024 → 31/05/2024
Status: Futuro
Créditos: 3
Período: Semestre 4