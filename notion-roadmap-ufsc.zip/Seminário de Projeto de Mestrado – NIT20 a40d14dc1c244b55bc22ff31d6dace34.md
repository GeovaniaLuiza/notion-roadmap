# Seminário de Projeto de Mestrado – NIT20

Datas: 04/06/2022 → 23/07/2022
Status: Terminado 🙌
Créditos: 2
Período: Semestre 2