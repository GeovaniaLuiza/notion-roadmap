# Web of Science

Tags: Secundária
Author/Owner: Kate Fletcher
URL: https://www.amazon.co.uk/Sustainable-Fashion-Textiles-Design-Journeys/dp/1844074811
Type: Book

<aside>
💡 **Notion Tip:** Take all your notes on this source right here to keep everything neatly bundled together. Never go hunting for scattered information again!

</aside>