# Políticas Públicas de Ciência, Tecnologia e Inovação e o Estado Brasileiro – NIT05

Datas: 15/09/2022 → 30/11/2022
Status: Terminado 🙌
Créditos: 3
Período: Semestre 2