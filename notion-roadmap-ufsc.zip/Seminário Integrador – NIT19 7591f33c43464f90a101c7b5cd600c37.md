# Seminário Integrador – NIT19

Datas: 15/03/2023 → 30/07/2023
Status: Terminado 🙌
Anexos: seminarioIntegrador.png
Créditos: 1
Período: Semestre 2