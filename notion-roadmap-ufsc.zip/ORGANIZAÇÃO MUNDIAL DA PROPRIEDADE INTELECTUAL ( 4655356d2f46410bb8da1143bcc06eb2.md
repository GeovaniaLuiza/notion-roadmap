# ORGANIZAÇÃO MUNDIAL DA PROPRIEDADE INTELECTUAL (OMPI)

Tags: Primária
Author/Owner: ORGANIZAÇÃO MUNDIAL DA PROPRIEDADE INTELECTUAL (OMPI
). Informação de Patente e Documentação, Genebra, Padrões - ST. 9., 1989.
URL: https://www.amazon.co.uk/Overdressed-Shockingly-High-Cheap-Fashion/dp/1591846544/ref=pd_sim_b_5?ie=UTF8&refRID=0WKDWT64SJ7T24233ME8
Type: Book

<aside>
💡 **Notion Tip:** Take all your notes on this source right here to keep everything neatly bundled together. Never go hunting for scattered information again!

</aside>