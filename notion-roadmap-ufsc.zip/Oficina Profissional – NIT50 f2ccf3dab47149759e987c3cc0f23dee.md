# Oficina Profissional – NIT50

Datas: 15/03/2023 → 30/07/2023
Status: Terminado 🙌
Créditos: 6
Notas: sem nota
Período: Semestre 3