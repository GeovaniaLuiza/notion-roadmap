# Disciplina eletiva/optativa B (sem professor(a))

Datas: 15/03/2023 → 30/07/2023
Status: Terminado 🙌
Créditos: 3
Período: Semestre 3