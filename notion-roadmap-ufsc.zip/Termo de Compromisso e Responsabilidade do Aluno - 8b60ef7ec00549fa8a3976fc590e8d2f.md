# Termo de Compromisso e Responsabilidade do Aluno - Assinar e entregar

Datas: 31/03/2022 → 23/07/2022
Status: Terminado 🙌
Créditos: 3
Notas: https://profnit.org.br/regimento-nacional/
Período: Semestre 1