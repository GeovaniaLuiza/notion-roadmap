# Transformação Digital

Comentário: Após a aula sobre o tema, descobri que gostaria de desenvolver algo nessa linha.
Fascinante?: Yes
Pergunta da pesquisa: Buscando a pergunta certa…
Situação: Pesquisando
Tags: inovação
Viável?: Yes