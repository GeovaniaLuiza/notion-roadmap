# Roadmap - PROFNIT

<aside>
💡 “Esse roadmap tem como objetivo guiar minha rota durante o mestrado profissional, para me **manter no caminho certo.”**  - Geovania Luiza Francisco.

</aside>

[Tópicos](To%CC%81picos%20a4715af0d33d429abf430cd628f5c7d0.csv)

[Fontes & Notas](Fontes%20&%20Notas%202b96fcf897974de3bf2fd1693ac7f06b.csv)

[⏰ LINHA DO TEMPO](%E2%8F%B0%20LINHA%20DO%20TEMPO%20ae340265c6c34e80bd5ed71c6a95acd9.csv)