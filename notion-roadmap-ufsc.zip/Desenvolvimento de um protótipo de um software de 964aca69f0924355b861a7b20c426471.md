# Desenvolvimento de um protótipo de um software de baixo custo para a busca automatizada de patentes por comando de voz

Comentário: Os desafios técnicos do projeto poderiam ultrapassar o tempo hábil para a entrega do mesmo.
Fascinante?: No
Pergunta da pesquisa: Como otimizar com software de baixo custo a busca de patentes para os pesquisadores?
Situação: Abandonado
Tags: Propriedade Intelectual, inovação
Viável?: Yes