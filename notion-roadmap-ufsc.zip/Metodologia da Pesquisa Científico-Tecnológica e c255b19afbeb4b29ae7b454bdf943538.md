# Metodologia da Pesquisa Científico-Tecnológica e Inovação – NIT04

Datas: 31/03/2022 → 02/06/2022
Status: Terminado 🙌
Créditos: 3
Período: Semestre 1