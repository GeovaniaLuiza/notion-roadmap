# Conceitos e Aplicações de Transferência de Tecnologia (TT) – NIT02

Datas: 01/09/2022 → 30/11/2022
Status: Terminado 🙌
Créditos: 3
Período: Semestre 2