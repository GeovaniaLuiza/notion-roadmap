# Submissão de artigo B1/B2

Datas: 15/03/2023 → 30/07/2023
Status: Terminado 🙌
Notas: Pré-requisito
Período: Semestre 3