# Negociacao Contratos e Formalizacao de Transferencia de Tecnologia

Datas: 15/03/2023 → 30/07/2023
Status: Terminado 🙌
Créditos: 3
Período: Semestre 3