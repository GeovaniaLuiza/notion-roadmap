# INPI: busca de registros

Tags: Primária
Author/Owner: Kate Fletcher, Lynda Grose
URL: https://www.gov.br/inpi/pt-br
Type: eBook

<aside>
💡 **Notion Tip:** Take all your notes on this source right here to keep everything neatly bundled together. Never go hunting for scattered information again!

</aside>