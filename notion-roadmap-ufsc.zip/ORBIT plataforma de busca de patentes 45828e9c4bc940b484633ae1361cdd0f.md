# ORBIT: plataforma de busca de patentes

Tags: Primária
URL: https://www.orbit.com/#PatentRegularAdvancedSearchPage
Type: Video

[https://www.youtube.com/watch?v=mdu5m9bh-oY](https://www.youtube.com/watch?v=mdu5m9bh-oY)