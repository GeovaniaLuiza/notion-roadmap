# Conceitos e Aplicações de Propriedade Intelectual (PI) – NIT01

Datas: 28/04/2022 → 03/06/2022
Status: Terminado 🙌
Créditos: 3
Período: Semestre 3