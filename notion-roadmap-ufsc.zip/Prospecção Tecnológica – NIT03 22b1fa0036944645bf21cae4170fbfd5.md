# Prospecção Tecnológica – NIT03

Datas: 10/06/2022 → 15/07/2022
Status: Terminado 🙌
Créditos: 3
Período: Semestre 1